var express = require('express');
var bodyParser = require('body-parser');
var path = require('path');
var Promise = require('promise');
var app = express();
var jenkins = require('./app');

/*
var logging = function(req, res, next){
    console.log(res.domain);
    next();
    
}
app.use(logging);
*/

app.set('view engine', 'ejs');
app.set('views',path.join(__dirname,'views'));
//Body Parser middleware
app.use(bodyParser.json());
app.use(bodyParser.urlencoded({extended: false}));
app.use(express.static(path.join(__dirname, 'public')));

var people = [
{
    name:'saran',
    age: 29
}
]

var users = [
    {
        first_name: 'Saran',
        last_name: 'Palivela',
        test: "Initial URL Saran",
    },
    {
        first_name: 'Siva',
        last_name: 'Narala',
        test: "Initial URL Siva",
    }
]

app.get('/', 
function(req,res){
    //res.status(200).send("Hello World");
    //res.json(users);
    var getJobList = new Promise(function(resolve,reject){
        
    });
    res.render('index', {
        title: 'Jenkins Job',
    }); 
});

app.post('/', 
function(req,res){
    //res.status(200).send("Hello World");
    //res.json(users);

    var createNewproject = function(){
        return new Promise(function(resolve, reject){
            var configfile = "config.xml";
            jenkins.newProject(req.body.team,req.body.project,req.body.jobName,configfile, function (err){
                if(!err)
                {
                   console.log(err);
                   resolve("Job Created");
                }
                else 
                {
                  reject(err);
                }

            });
        });

    };

    createNewproject()
    .then(function(result){
        res.send(result);
    })
    .catch(function(result) {
        res.send("Job Failed");
    });
        
    
    
    // var configfile = "config.xml";
    // var err = jenkins.newProject(req.body.team,req.body.project,req.body.jobName,configfile);
    // if(!err)
    // {
    // res.send("Job Created");
    // }
    // else 
    // {
    //     res.send(err);
    // }
    //jenkins.newjob(req.body.team,req.body.team+Delimiter+req.body.project+Delimiter,req.body.jobName);
    //promise = jenkins.jobInFolder("config.xml",req.body.jobName);
    //jenkins.job("config.xml", Delimiter+req.body.jobName);
   
    
});

// Starting the server with above config
app.listen(9000, function(){
  console.log('Server started!!!');
});