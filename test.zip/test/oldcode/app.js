

var shell1 = require('shelljs');
var fs = require('fs');




var link = 'wget --user=jenkins --password=jenkins --auth-no-challenge -q --output-document - \'http://lab.psk.com:8080/crumbIssuer/api/xml?xpath=concat(//crumbRequestField,":",//crumb)\'';
var crumb1 = shell1.exec(link);
var jenkins = require('jenkins')({ baseUrl: 'http://jenkins:jenkins@lab.psk.com:8080', crumbIssuer: true, header: { "User-Agent": "jenkins", "Authorization": "jenkins", "Jenkins-Crumb": crumb1 }});
//var jenkins = require('jenkins')({ baseUrl: 'http://jenkins:jenkins@lab.psk.com:8080', crumbIssuer: true });


 jenkins.info(function(err, data) {
    if (err) throw err;
        console.log('info', data);
 });


var config = fs.readFileSync("config.xml").toString();
//console.log(config);
console.log("Creating job");
/*

jenkins.job.create('testjob1', config , error1);


function error1 (err, data, response) {
  if (err) throw err;
}

var xml1 = 'config.xml';

jenkins.job.create('newJob1', xml1, function(err) {
    if (err) throw err;
  });


jenkins.job.config({ name: 'testjob' }, function(err, xml) {
  if (err) throw err;

  jenkins.job.create({ name: 'newJob', xml: xml }, function(err) {
    if (err) throw err;
  });
});

*/


var jenkinsapi = require('jenkins-api');
var jenkins1 = jenkinsapi.init('http://jenkins:853c0f3d5001ef551bb63c26cf80d07d@lab.psk.com:8080', {crumbIssuer: true} );

/*
jenkins1.all_jobs(function(err, data) {
  if (err){ return console.log(err); }
  console.log(data)
});

*/

jenkins1.create_job('job-in-jenkins', config , function(err, data) {
  if (err){ return console.log(err); }
  console.log(data)
});

/*
jenkins1.get_config_xml('testjob', function(error, data) { 
   // console.log(data);  
    jenkins1.create_job('test-copy', data, function(error1, data1) {
       console.log(data1); 
    });
});

*/
