// var Vehicle = function() {};
// Vehicle.prototype.drive = function() {  
//                 console.log('vrooom...');};
//         var Car = function() {};
//         Car.prototype = new Vehicle();
//         Car.prototype.honk = function() {  console.log('honk honk');};
//         var myCar = new Car();myCar.honk();   // outputs "honk honk"myCar.drive();  // outputs "vrooom..."


// Object.create = function(o) {  
//     var F = function() {};  
//     F.prototype = o;   
//     return new F();
// };

// var vehicle = {}; 

// vehicle.drive = function () {  
//     console.log('vrooom...'); 
// };

// var car = Object.create(vehicle);
// value = typeof car; 
// console.log("4th "+ value);


// car.honk = function() {  console.log('honk honk');};
// var myCar = Object.create(car);
// myCar.honk();   // outputs "honk honk"
// myCar.drive();  // outputs "vrooom..."

/*Creating a function/Class in java Directly

var makeCar = function() {
    var newCar = {}; 
     newCar.honk = function() {
         console.log('honk honk newCar'); 
    };
    return newCar;
  };
  // makeCar().honk(); //Referrring a object directly without new.
 var myCar = makeCar();
 myCar.honk();
*/

//Creating a function using constructor 

// var Car = function() {  
//     this.honk = function() {    
//         console.log('honk honk Car');   
//     };
// };
//  //Car().honk(); will not work as the object is not created.
//  var myCar = new Car();
//  myCar.honk();

// var Car = function() { 
//       this.honk = function() {  
//             console.log('honk honk');   
//         };
// };
// var myCar1 = new Car();
// var myCar2 = new Car();
// console.log(myCar1.constructor);  // outputs [Function: Car]
// console.log(myCar2.constructor);  // outputs [Function: Car]
// myCar1.constructor();
// myCar2.honk();

// Car.prototype.drive = function() { 
//      console.log('vrooom...');
// };

// myCar1.drive();  // executes Car.prototype.drive() and outputs "vrooom..."
// myCar2.drive();  // executes Car.prototype.drive() and outputs "vrooom..."

// myCar2.drive = "tested";

// console.log(myCar2.drive);

// var Vehicle = function() {};
// Vehicle.prototype.drive = function() { 
//      console.log('vrooom...');
// };
// var Car = function() {};
// Car.prototype = new Vehicle();
// Car.prototype.honk = function() { 
//      console.log('honk honk');
// };

// var myCar = new Car();
// myCar.honk();   // outputs "honk honk"
// myCar.drive();  // outputs "vrooom..."

// var Bike = function() {};

// Bike.prototype = new Vehicle();

// Bike.prototype.ring = function(){
//  console.log("ring.....");
// };

// var myBike = new Bike();

// myBike.drive();
// myBike.ring();
