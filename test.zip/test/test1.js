function one(x,y,callback){
    var z= x+y;
 // console.log("Function "+z); 
//   callback = function callback(z){
//     console.log("Inside callback");
//     return z;
//   };
callback(z);
}


var promise1 = new Promise(function(resolve,reject){
        var a = 2;
        var b = 5;
        one(a,b, function(c){
            resolve(c);
        });
})
//console.log(typeof one);

function three(){
    a = 2;
    b = 3;
    one (a,b, function(c){
        console.log("from callback");
        console.log(typeof c);
        console.log(c);
    });
}
//three();


promise1
.then(function(k){
  console.log(k);
})




jenkins.job.list(function(err, data) {
    if (err) throw err;
    
    //console.log(myObj);
    // var jsonObj = JSON.parse(data);
    // console.log(jsonObj);
    // var jsonData = JSON.stringify(jsonObj);
    // console.log(jsonData);
    // console.log(typeof jsonData);
    // for( var value in data){
    //   console.log(typeof value);
    // }
    //console.log(data);
    console.log("Raw data");
   // console.log(data);
    var datainString = JSON.stringify(data);
    console.log("Data in Stringify");
   // console.log(datainString);
    console.log("data in JSON");
    var parse1 =JSON.parse(datainString);
  //  console.log(parse1);
    for(var k in data) {
      if(data[k]._class === "com.cloudbees.hudson.plugins.folder.Folder"){
        console.log(data[k].name);
          jenkins.job.listall("/job/"+data[k].name, function (err,data1){
            if(data1){
              for(var j in data1) {
                if(data1[j]._class === "com.cloudbees.hudson.plugins.folder.Folder"){
                  console.log(data1[j].name);
                }
              }
            }
          });
  
        
        
        // new Promise(function(resolve,reject){
        //   jenkins.job.listall("/job/"+data[k].name, function (err,data1){
        //     if(data1){
        //       resolve(data1);
        //     }
        //   });
  
        // }).then(function(data1){
        //   for(var j in data1) {
        //     if(data1[j]._class === "com.cloudbees.hudson.plugins.folder.Folder"){
        //       console.log(data1[j].name);
        //     }
        //  }
  
        // });
  
      }
    }
   // console.log(Array.isArray(data));
  
  });
  