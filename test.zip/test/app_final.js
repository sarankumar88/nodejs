var shell1 = require('shelljs');
var fs = require('fs');

//Creating jenkins object
var link = 'wget --user=jenkins --password=jenkins --auth-no-challenge -q --output-document - \'http://lab.psk.com:8080/crumbIssuer/api/xml?xpath=concat(//crumbRequestField,":",//crumb)\'';
var crumb1 = shell1.exec(link);
var jenkins = require('jenkins')({ baseUrl: 'http://jenkins:jenkins@lab.psk.com:8080/', crumbIssuer: true, header: { "User-Agent": "jenkins", "Authorization": "jenkins", "Jenkins-Crumb": crumb1 }});
var folderconfig = "configfolder.xml";


jenkins.job.list(function(err, data) {
  if (err) throw err;
  
  //console.log(myObj);
  // var jsonObj = JSON.parse(data);
  // console.log(jsonObj);
  // var jsonData = JSON.stringify(jsonObj);
  // console.log(jsonData);
  // console.log(typeof jsonData);
  // for( var value in data){
  //   console.log(typeof value);
  // }
  //console.log(data);
  var datainJson = JSON.stringify(data);
  console.log(datainJson[0]);
  for(var k in data) {
    if(data[k]._class === "com.cloudbees.hudson.plugins.folder.Folder"){
    console.log(data[k].name);
    }
  }
  console.log(Array.isArray(data));

});

function job(jobname,configfile, callback) {
  var config = fs.readFileSync(configfile).toString();
  jenkins.job.create(jobname, config , function error2 (err, data, response) {
    callback(err,data);
  });

}

function jobInFolder(jobpath,jobname,configfile, callback1) {
  var config = fs.readFileSync(configfile).toString();
  jenkins.job.createfolder(jobname, config , jobpath, function error1 (err, data, response) {
    callback1(err,data);
  });

}


function newProject(team, project, jobname, configfile, pCallback) {
  var Delimiter = "/job/";

  var teamFunction = function() {
  return new Promise(function(resolve, reject) {
    console.log("Creating Team's folder");
    console.log(team+" "+folderconfig);
    job(team, folderconfig, function(err,data){
      if(!err) {
        resolve("Team Success");
      }
      if(err) {
        reject(err);
      }
    });
  });
};

var projectFunction = function() {
  return new Promise(function(resolve, reject) {
    console.log("Creating Project folder");
    console.log(Delimiter+team+" "+project+" "+folderconfig);
    jobInFolder( Delimiter+team, project, folderconfig, function(err, data){
      if(!err) {
        resolve("Project Success");
      }
      if(err) {
        console.log("Error after Project folder creation");
        reject(err);
      }
    }); 
  });
};

var jobFunction = function(){
  return new Promise(function(resolve, reject){
    console.log("Creating Job under Project Folder");
    jobInFolder(Delimiter+team+Delimiter+project,jobname,configfile, function(err,data){
        if(!err){
          resolve("Job created under Project Folder");
        }
        if(err){
          console.log(err);
          reject(err);
        }
    })
  })
}
teamFunction()
.then(function(result){
  console.log("team folder created successfully"+ result);
  return projectFunction();
})
.then(function(result){
  console.log("Project Folder created successfully." + result);
  return jobFunction();
})
.then(function(result){
  console.log("Job Created successfully." + result);
  pCallback();
})
.catch(function (err) {
      console.log("Error!!!");
      console.log(err);
      pCallback(err);
    });
}
 

// let jobFunction = function(message) {
//   return new Promise(function(resolve, reject) {
//     console.log("Creating Job");
//     console.log(Delimiter+team+Delimiter+project+" "+jobname+" "+configfile);
//     var err = jobInFolder(Delimiter+team+Delimiter+project, jobname, configfile);
//     if(!err[0]) {
//       console.log("No error after job creation");resolve(err[1]);console.log("resolve job called successfully");};
//     if(err[0]) {console.log("Error after job creation");reject(err[0])};

//     //resolve('Job Created');
//   });
// };





  exports.job = job;
  exports.jobInFolder = jobInFolder;
  exports.newProject = newProject;

  //jobInFolder("/job/lab4/job/sub1","job1","config.xml");