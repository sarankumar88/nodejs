var shell1 = require('shelljs');
var fs = require('fs');

//Creating jenkins object
var link = 'wget --user=jenkins --password=jenkins --auth-no-challenge -q --output-document - \'http://lab.psk.com:8080/crumbIssuer/api/xml?xpath=concat(//crumbRequestField,":",//crumb)\'';
var crumb1 = shell1.exec(link);
var jenkins = require('jenkins')({ baseUrl: 'http://jenkins:jenkins@lab.psk.com:8080/', crumbIssuer: true, header: { "User-Agent": "jenkins", "Authorization": "jenkins", "Jenkins-Crumb": crumb1 }});
var Promise = require('promise');
var folderconfig = "configfolder.xml";

function job(jobname,configfile) {
  var err,data;
  console.log("Creating job");
  var config = fs.readFileSync(configfile).toString();
  jenkins.job.create(jobname, config , error2);
  function error2 (err, data, response) {
    if(err) {console.log("Error while executing job");console.log(err);this.err = err;this.data = data;};
  }
    return (err,data);
}
function jobInFolder(jobpath,jobname,configfile) {
  var err,data;
  console.log("Creating job in folder");
  var config = fs.readFileSync(configfile).toString();
  jenkins.job.createfolder(jobname, config , jobpath, error1);
  function error1 (err, data, response) {

    if(err) {console.log("Error while creating job in folder");console.log(err);this.err = err;this.data = data;};
  }
  return (err,data);
}

function newProject(team, project, jobname, configfile) {
  var err;
  var Delimiter = "/job/";
  var jenkinsjobFolder = function (whichJob) {
  var p1 = new Promise(function (resolve, reject) {
                             if (whichJob === "team")
                             {
                             console.log("Creating Team's folder");
                             console.log(team+" "+folderconfig);
                             var err,data = job(team, folderconfig);
                             if(!err) {console.log("No error after team folder creation");resolve(data);console.log("resolve team called successfully");};
                             if(err) {console.log("Error after team folder creation");reject(err)};
                             }
                             if (whichJob === "project")
                             {
                              console.log("Creating Project folder");
                              console.log(Delimiter+team+" "+project+" "+folderconfig);
                              var err,data = jobInFolder( Delimiter+team, project, folderconfig);
                              if(!err) {console.log("No error after Project folder creation");resolve(data);console.log("resolve project called successfully");};
                              if(err) {console.log("Error after Project folder creation");reject(err)};
                             }
                             if (whichJob === "job")
                             {
                              console.log("Creating Job");
                              console.log(Delimiter+team+Delimiter+project+" "+jobname+" "+configfile);
                              var err,data = jobInFolder(Delimiter+team+Delimiter+project, jobname, configfile);
                              if(!err) {console.log("No error after job creation");resolve(data);console.log("resolve job called successfully");};
                              if(err) {console.log("Error after job creation");reject(err)};
                             }
                             
  });
  return p1;
}
jenkinsjobFolder("team").then(function () {
  console.log("resolved team successfully");
    return jenkinsjobFolder("project");
  })
  // .then(function () {
  //   console.log("resolved project successfully");
  //   return jenkinsjobFolder("job");
  // })
  .catch(function (err) {
    console.error(err);
    this.err = err;
  });
 return err;
}

  exports.job = job;
  exports.jobInFolder = jobInFolder;
  exports.newProject = newProject;

  //jobInFolder("/job/lab4/job/sub1","job1","config.xml");